from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import socket
import struct
from dataclasses import dataclass, field
from typing import Optional

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .raw_websocket import RawWebSocket, WsHandshakeError, set_tcp_opts

HANDSHAKE_LEN = 64
SKIP_LEN = 8
PREKEY_LEN = 32
KEY_LEN = 32
IV_LEN = 16
PROTO_TAG_POS = 56
DC_IDX_POS = 60
ZERO_64 = b"\x00" * 64

PROTO_TAG_ABRIDGED = b"\xef\xef\xef\xef"
PROTO_TAG_INTERMEDIATE = b"\xee\xee\xee\xee"
PROTO_TAG_SECURE = b"\xdd\xdd\xdd\xdd"
PROTO_TAG_PADDED_INTERMEDIATE = PROTO_TAG_SECURE

PROTO_ABRIDGED_INT = 0xEFEFEFEF
PROTO_INTERMEDIATE_INT = 0xEEEEEEEE
PROTO_PADDED_INTERMEDIATE_INT = 0xDDDDDDDD

RESERVED_FIRST_BYTES = {0xEF}
RESERVED_STARTS = {
    b"HEAD",
    b"POST",
    b"GET ",
    PROTO_TAG_INTERMEDIATE,
    PROTO_TAG_PADDED_INTERMEDIATE,
    b"\x16\x03\x01\x02",
}
RESERVED_CONTINUE = b"\x00\x00\x00\x00"

DC_DEFAULT_IPS: dict[int, str] = {
    1: "149.154.175.50",
    2: "149.154.167.51",
    3: "149.154.175.100",
    4: "149.154.167.91",
    5: "149.154.171.5",
    203: "149.154.175.50",
}

FLOWSEAL_STYLE_DEFAULTS: dict[int, str] = {
    2: "149.154.167.220",
    4: "149.154.167.220",
}

# Fallback Cloudflare domains used by Flowseal-style routing.
# Direct WS to Telegram DC can return 302 or be unavailable on filtered networks;
# these domains provide a second WS route before the last-resort direct TCP fallback.
DEFAULT_CFPROXY_DOMAINS: tuple[str, ...] = (
    "pclead.co.uk",
    "offshor.co.uk",
    "cakeisalie.co.uk",
    "noskomnadzor.co.uk",
    "lovetrue.co.uk",
    "sorokdva.co.uk",
    "pyatdesyatdva.co.uk",
    "kartoshka.co.uk",
    "sorokodin.co.uk",
    "pyatdesyatodin.co.uk",
)



class MTProtoError(Exception):
    pass


@dataclass
class HandshakeInfo:
    dc: int
    is_media: bool
    proto_tag: bytes
    proto_int: int
    client_prekey_iv: bytes


@dataclass
class CryptoCtx:
    client_decryptor: object
    client_encryptor: object
    telegram_encryptor: object
    telegram_decryptor: object


class MsgSplitter:
    """Splits encrypted Telegram-side stream into MTProto transport packets for WS frames."""

    def __init__(self, relay_init: bytes, proto_int: int):
        self.proto_int = proto_int
        key = relay_init[SKIP_LEN : SKIP_LEN + PREKEY_LEN]
        iv = relay_init[SKIP_LEN + PREKEY_LEN : SKIP_LEN + PREKEY_LEN + IV_LEN]
        self.decryptor = Cipher(algorithms.AES(key), modes.CTR(iv)).encryptor()
        self.decryptor.update(ZERO_64)
        self.cipher_buf = bytearray()
        self.plain_buf = bytearray()
        self.disabled = False

    def feed(self, chunk: bytes) -> list[bytes]:
        if not chunk:
            return []
        if self.disabled:
            return [chunk]
        self.cipher_buf.extend(chunk)
        self.plain_buf.extend(self.decryptor.update(chunk))
        parts: list[bytes] = []
        while self.cipher_buf:
            packet_len = self._next_packet_len()
            if packet_len is None:
                break
            if packet_len <= 0:
                parts.append(bytes(self.cipher_buf))
                self.cipher_buf.clear()
                self.plain_buf.clear()
                self.disabled = True
                break
            parts.append(bytes(self.cipher_buf[:packet_len]))
            del self.cipher_buf[:packet_len]
            del self.plain_buf[:packet_len]
        return parts

    def flush(self) -> list[bytes]:
        if not self.cipher_buf:
            return []
        tail = bytes(self.cipher_buf)
        self.cipher_buf.clear()
        self.plain_buf.clear()
        return [tail]

    def _next_packet_len(self) -> Optional[int]:
        if not self.plain_buf:
            return None
        if self.proto_int == PROTO_ABRIDGED_INT:
            return self._next_abridged_len()
        if self.proto_int in (PROTO_INTERMEDIATE_INT, PROTO_PADDED_INTERMEDIATE_INT):
            return self._next_intermediate_len()
        return 0

    def _next_abridged_len(self) -> Optional[int]:
        first = self.plain_buf[0]
        if first in (0x7F, 0xFF):
            if len(self.plain_buf) < 4:
                return None
            payload_len = int.from_bytes(self.plain_buf[1:4], "little") * 4
            header_len = 4
        else:
            payload_len = (first & 0x7F) * 4
            header_len = 1
        if payload_len <= 0:
            return 0
        packet_len = header_len + payload_len
        if len(self.plain_buf) < packet_len:
            return None
        return packet_len

    def _next_intermediate_len(self) -> Optional[int]:
        if len(self.plain_buf) < 4:
            return None
        payload_len = struct.unpack_from("<I", self.plain_buf, 0)[0] & 0x7FFFFFFF
        if payload_len <= 0:
            return 0
        packet_len = 4 + payload_len
        if len(self.plain_buf) < packet_len:
            return None
        return packet_len


def parse_dc_redirects(value: str) -> dict[int, str]:
    result = dict(FLOWSEAL_STYLE_DEFAULTS)
    if not value.strip():
        return result
    result.clear()
    normalized = value.replace("\n", ",").replace(";", ",")
    for item in normalized.split(","):
        item = item.strip()
        if not item:
            continue
        if ":" not in item:
            raise ValueError(f"DC запись должна быть в формате DC:IP, получено: {item}")
        dc_s, ip = item.split(":", 1)
        dc = int(dc_s.strip())
        ip = ip.strip()
        socket.inet_aton(ip)
        result[dc] = ip
    return result


def dc_redirects_to_text(mapping: dict[int, str]) -> str:
    return "\n".join(f"{dc}:{ip}" for dc, ip in sorted(mapping.items()))


def parse_cfproxy_domains(value: str) -> list[str]:
    """Return user domains or the built-in fallback pool."""
    normalized = (value or "").replace("\n", ",").replace(";", ",")
    domains: list[str] = []
    seen: set[str] = set()
    source = [item.strip().lower() for item in normalized.split(",") if item.strip()]
    if not source:
        source = list(DEFAULT_CFPROXY_DOMAINS)
    for domain in source:
        if not is_valid_domain(domain):
            raise ValueError(f"Некорректный домен CF fallback: {domain}")
        if domain not in seen:
            seen.add(domain)
            domains.append(domain)
    return domains


def is_valid_domain(domain: str) -> bool:
    if not domain or len(domain) > 253 or domain.startswith(".") or domain.endswith("."):
        return False
    labels = domain.split(".")
    if len(labels) < 2:
        return False
    for label in labels:
        if not label or len(label) > 63:
            return False
        if label[0] == "-" or label[-1] == "-":
            return False
        if not all(ch.isalnum() or ch == "-" for ch in label):
            return False
    return len(labels[-1]) >= 2 and any(ch.isalpha() for ch in labels[-1])


def normalize_secret(secret: str | None = None) -> str:
    raw = (secret or "").strip().lower()
    if raw.startswith("dd"):
        raw = raw[2:]
    if len(raw) == 32:
        try:
            bytes.fromhex(raw)
            return raw
        except ValueError:
            pass
    return os.urandom(16).hex()


def proxy_link_host(host: str) -> str:
    host = (host or "127.0.0.1").strip()
    if host in {"0.0.0.0", "::", "*", ""}:
        return "127.0.0.1"
    return host


def build_mtproto_link(host: str, port: int, secret: str) -> str:
    # dd = official MTProxy random-padding/secure mode.
    return f"tg://proxy?server={proxy_link_host(host)}&port={int(port)}&secret=dd{normalize_secret(secret)}"


def try_handshake(handshake: bytes, secret: bytes) -> Optional[HandshakeInfo]:
    if len(handshake) != HANDSHAKE_LEN:
        return None
    prekey_iv = handshake[SKIP_LEN : SKIP_LEN + PREKEY_LEN + IV_LEN]
    prekey = prekey_iv[:PREKEY_LEN]
    iv = prekey_iv[PREKEY_LEN:]
    key = hashlib.sha256(prekey + secret).digest()
    decryptor = Cipher(algorithms.AES(key), modes.CTR(iv)).encryptor()
    decrypted = decryptor.update(handshake)
    proto_tag = decrypted[PROTO_TAG_POS : PROTO_TAG_POS + 4]
    if proto_tag not in (PROTO_TAG_ABRIDGED, PROTO_TAG_INTERMEDIATE, PROTO_TAG_PADDED_INTERMEDIATE):
        return None
    dc_idx = int.from_bytes(decrypted[DC_IDX_POS : DC_IDX_POS + 2], "little", signed=True)
    dc = abs(dc_idx)
    is_media = dc_idx < 0
    proto_int = {
        PROTO_TAG_ABRIDGED: PROTO_ABRIDGED_INT,
        PROTO_TAG_INTERMEDIATE: PROTO_INTERMEDIATE_INT,
        PROTO_TAG_PADDED_INTERMEDIATE: PROTO_PADDED_INTERMEDIATE_INT,
    }[proto_tag]
    return HandshakeInfo(dc=dc, is_media=is_media, proto_tag=proto_tag, proto_int=proto_int, client_prekey_iv=prekey_iv)


def generate_relay_init(proto_tag: bytes, dc_idx: int) -> bytes:
    while True:
        rnd = bytearray(os.urandom(HANDSHAKE_LEN))
        if rnd[0] in RESERVED_FIRST_BYTES:
            continue
        if bytes(rnd[:4]) in RESERVED_STARTS:
            continue
        if rnd[4:8] == RESERVED_CONTINUE:
            continue
        break

    rnd_bytes = bytes(rnd)
    enc_key = rnd_bytes[SKIP_LEN : SKIP_LEN + PREKEY_LEN]
    enc_iv = rnd_bytes[SKIP_LEN + PREKEY_LEN : SKIP_LEN + PREKEY_LEN + IV_LEN]
    encryptor = Cipher(algorithms.AES(enc_key), modes.CTR(enc_iv)).encryptor()
    dc_bytes = struct.pack("<h", dc_idx)
    tail_plain = proto_tag + dc_bytes + os.urandom(2)
    encrypted_full = encryptor.update(rnd_bytes)
    keystream_tail = bytes(encrypted_full[i] ^ rnd_bytes[i] for i in range(PROTO_TAG_POS, HANDSHAKE_LEN))
    encrypted_tail = bytes(tail_plain[i] ^ keystream_tail[i] for i in range(8))
    result = bytearray(rnd_bytes)
    result[PROTO_TAG_POS:HANDSHAKE_LEN] = encrypted_tail
    return bytes(result)


def build_crypto_ctx(client_prekey_iv: bytes, secret: bytes, relay_init: bytes) -> CryptoCtx:
    client_dec_prekey = client_prekey_iv[:PREKEY_LEN]
    client_dec_iv = client_prekey_iv[PREKEY_LEN:]
    client_dec_key = hashlib.sha256(client_dec_prekey + secret).digest()

    client_enc_prekey_iv = client_prekey_iv[::-1]
    client_enc_key = hashlib.sha256(client_enc_prekey_iv[:PREKEY_LEN] + secret).digest()
    client_enc_iv = client_enc_prekey_iv[PREKEY_LEN:]

    client_decryptor = Cipher(algorithms.AES(client_dec_key), modes.CTR(client_dec_iv)).encryptor()
    client_encryptor = Cipher(algorithms.AES(client_enc_key), modes.CTR(client_enc_iv)).encryptor()
    client_decryptor.update(ZERO_64)

    relay_enc_key = relay_init[SKIP_LEN : SKIP_LEN + PREKEY_LEN]
    relay_enc_iv = relay_init[SKIP_LEN + PREKEY_LEN : SKIP_LEN + PREKEY_LEN + IV_LEN]
    relay_dec_prekey_iv = relay_init[SKIP_LEN : SKIP_LEN + PREKEY_LEN + IV_LEN][::-1]
    relay_dec_key = relay_dec_prekey_iv[:KEY_LEN]
    relay_dec_iv = relay_dec_prekey_iv[KEY_LEN:]

    telegram_encryptor = Cipher(algorithms.AES(relay_enc_key), modes.CTR(relay_enc_iv)).encryptor()
    telegram_decryptor = Cipher(algorithms.AES(relay_dec_key), modes.CTR(relay_dec_iv)).encryptor()
    telegram_encryptor.update(ZERO_64)

    return CryptoCtx(
        client_decryptor=client_decryptor,
        client_encryptor=client_encryptor,
        telegram_encryptor=telegram_encryptor,
        telegram_decryptor=telegram_decryptor,
    )


def canonical_dc(dc: int) -> int:
    return 2 if dc == 203 else dc


def ws_domains(dc: int, is_media: bool) -> list[str]:
    dc = canonical_dc(dc)
    if is_media:
        return [f"kws{dc}-1.web.telegram.org", f"kws{dc}.web.telegram.org"]
    return [f"kws{dc}.web.telegram.org", f"kws{dc}-1.web.telegram.org"]


@dataclass
class MTProtoLocalService:
    listen_host: str
    listen_port: int
    secret_hex: str
    dc_redirects_text: str = "2:149.154.167.220\n4:149.154.167.220"
    enable_cf_fallback: bool = True
    cfproxy_domains_text: str = ""
    enable_tcp_fallback: bool = True
    buffer_size: int = 256 * 1024
    logger: logging.Logger | None = None
    _server: asyncio.AbstractServer | None = field(default=None, init=False)
    _tasks: set[asyncio.Task] = field(default_factory=set, init=False)
    _secret_bytes: bytes = field(default=b"", init=False)
    _dc_redirects: dict[int, str] = field(default_factory=dict, init=False)
    _cfproxy_domains: list[str] = field(default_factory=list, init=False)

    async def start(self) -> None:
        if self._server is not None:
            return
        self.secret_hex = normalize_secret(self.secret_hex)
        self._secret_bytes = bytes.fromhex(self.secret_hex)
        self._dc_redirects = parse_dc_redirects(self.dc_redirects_text)
        self._cfproxy_domains = parse_cfproxy_domains(self.cfproxy_domains_text)
        self._server = await asyncio.start_server(self._client_connected, self.listen_host, self.listen_port)
        for sock in self._server.sockets or []:
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
        sockets = ", ".join(str(sock.getsockname()) for sock in (self._server.sockets or []))
        self._log(logging.INFO, "Локальный MTProto-прокси запущен: %s", sockets)
        self._log(logging.INFO, "MTProto secret: dd%s", self.secret_hex)
        self._log(logging.INFO, "Режим транспорта: Flowseal-compatible MTProto → WS /apiws")
        if self.enable_cf_fallback:
            self._log(logging.INFO, "CF fallback: включён (%d доменов)", len(self._cfproxy_domains))
        else:
            self._log(logging.INFO, "CF fallback: отключён")

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        for task in list(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._log(logging.INFO, "Локальный MTProto-прокси остановлен")

    def _client_connected(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        task = asyncio.create_task(self._handle_client(reader, writer))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = writer.get_extra_info("peername")
        label = f"{peer[0]}:{peer[1]}" if peer else "?"
        set_tcp_opts(writer, self.buffer_size)
        try:
            handshake = await asyncio.wait_for(reader.readexactly(HANDSHAKE_LEN), timeout=12)
            info = try_handshake(handshake, self._secret_bytes)
            if info is None:
                self._log(logging.WARNING, "[%s] неверный MTProto handshake или secret", label)
                return

            dc_idx = -info.dc if info.is_media else info.dc
            relay_init = generate_relay_init(info.proto_tag, dc_idx)
            ctx = build_crypto_ctx(info.client_prekey_iv, self._secret_bytes, relay_init)
            splitter = MsgSplitter(relay_init, info.proto_int)
            media = " media" if info.is_media else ""
            self._log(logging.INFO, "[%s] Telegram -> DC%d%s", label, info.dc, media)

            ok = await self._connect_ws_and_bridge(reader, writer, info, relay_init, ctx, splitter, label)
            if not ok and self.enable_cf_fallback:
                splitter_cf = MsgSplitter(relay_init, info.proto_int)
                ok = await self._connect_cf_and_bridge(reader, writer, info, relay_init, ctx, splitter_cf, label)
            if not ok and self.enable_tcp_fallback:
                await self._connect_tcp_and_bridge(reader, writer, info, relay_init, ctx, label)
        except asyncio.IncompleteReadError:
            pass
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._log(logging.WARNING, "[%s] соединение завершилось с ошибкой: %s", label, exc)
        finally:
            await safe_close_writer(writer)

    async def _connect_ws_and_bridge(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        info: HandshakeInfo,
        relay_init: bytes,
        ctx: CryptoCtx,
        splitter: MsgSplitter,
        label: str,
    ) -> bool:
        target_ip = self._dc_redirects.get(canonical_dc(info.dc))
        if not target_ip:
            self._log(logging.INFO, "[%s] Для DC%d нет WS IP — пропускаю WS", label, info.dc)
            return False

        for domain in ws_domains(info.dc, info.is_media):
            try:
                self._log(logging.INFO, "[%s] WS %s через %s", label, domain, target_ip)
                ws = await RawWebSocket.connect(
                    target_ip,
                    domain,
                    timeout=10,
                    buffer_size=self.buffer_size,
                )
                if getattr(ws, "relaxed_tls", False):
                    self._log(logging.INFO, "[%s] TLS CA fallback применён для %s", label, domain)
                await ws.send(relay_init)
                await self._bridge_ws(reader, writer, ws, ctx, splitter, label)
                return True
            except WsHandshakeError as exc:
                self._log(logging.WARNING, "[%s] WS handshake %s: %s", label, domain, exc)
                continue
            except Exception as exc:
                self._log(logging.WARNING, "[%s] WS %s недоступен: %s", label, domain, exc)
                continue
        return False

    async def _connect_cf_and_bridge(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        info: HandshakeInfo,
        relay_init: bytes,
        ctx: CryptoCtx,
        splitter: MsgSplitter,
        label: str,
    ) -> bool:
        if not self._cfproxy_domains:
            return False
        media = " media" if info.is_media else ""
        for base_domain in self._cfproxy_domains:
            domain = f"kws{canonical_dc(info.dc)}.{base_domain}"
            try:
                self._log(logging.INFO, "[%s] CF fallback DC%d%s -> %s", label, info.dc, media, domain)
                ws = await RawWebSocket.connect(
                    domain,
                    domain,
                    timeout=10,
                    buffer_size=self.buffer_size,
                )
                if getattr(ws, "relaxed_tls", False):
                    self._log(logging.INFO, "[%s] TLS CA fallback применён для %s", label, domain)
                await ws.send(relay_init)
                await self._bridge_ws(reader, writer, ws, ctx, splitter, label)
                return True
            except Exception as exc:
                self._log(logging.WARNING, "[%s] CF fallback %s недоступен: %s", label, domain, exc)
                continue
        return False


    async def _connect_tcp_and_bridge(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        info: HandshakeInfo,
        relay_init: bytes,
        ctx: CryptoCtx,
        label: str,
    ) -> None:
        target_ip = DC_DEFAULT_IPS.get(canonical_dc(info.dc))
        if not target_ip:
            raise MTProtoError(f"Нет fallback IP для DC{canonical_dc(info.dc)}")
        self._log(logging.INFO, "[%s] TCP fallback DC%d -> %s:443", label, canonical_dc(info.dc), target_ip)
        remote_reader, remote_writer = await asyncio.wait_for(asyncio.open_connection(target_ip, 443), timeout=10)
        set_tcp_opts(remote_writer, self.buffer_size)
        remote_writer.write(relay_init)
        await remote_writer.drain()
        await self._bridge_tcp(reader, writer, remote_reader, remote_writer, ctx, label)

    async def _bridge_ws(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        ws: RawWebSocket,
        ctx: CryptoCtx,
        splitter: MsgSplitter,
        label: str,
    ) -> None:
        async def client_to_ws() -> None:
            try:
                while not reader.at_eof():
                    chunk = await reader.read(self.buffer_size)
                    if not chunk:
                        break
                    plain = ctx.client_decryptor.update(chunk)
                    encrypted = ctx.telegram_encryptor.update(plain)
                    parts = splitter.feed(encrypted)
                    if parts:
                        await ws.send_batch(parts)
                tail = splitter.flush()
                if tail:
                    await ws.send_batch(tail)
            finally:
                await ws.close()

        async def ws_to_client() -> None:
            try:
                while True:
                    message = await ws.recv()
                    if message is None:
                        break
                    plain = ctx.telegram_decryptor.update(message)
                    encrypted = ctx.client_encryptor.update(plain)
                    writer.write(encrypted)
                    await writer.drain()
            finally:
                await safe_close_writer(writer)

        await wait_pair(client_to_ws(), ws_to_client(), label, self.logger)

    async def _bridge_tcp(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        remote_reader: asyncio.StreamReader,
        remote_writer: asyncio.StreamWriter,
        ctx: CryptoCtx,
        label: str,
    ) -> None:
        async def client_to_remote() -> None:
            try:
                while not reader.at_eof():
                    chunk = await reader.read(self.buffer_size)
                    if not chunk:
                        break
                    plain = ctx.client_decryptor.update(chunk)
                    encrypted = ctx.telegram_encryptor.update(plain)
                    remote_writer.write(encrypted)
                    await remote_writer.drain()
            finally:
                await safe_close_writer(remote_writer)

        async def remote_to_client() -> None:
            try:
                while not remote_reader.at_eof():
                    chunk = await remote_reader.read(self.buffer_size)
                    if not chunk:
                        break
                    plain = ctx.telegram_decryptor.update(chunk)
                    encrypted = ctx.client_encryptor.update(plain)
                    writer.write(encrypted)
                    await writer.drain()
            finally:
                await safe_close_writer(writer)

        await wait_pair(client_to_remote(), remote_to_client(), label, self.logger)

    def _log(self, level: int, message: str, *args) -> None:
        if self.logger:
            self.logger.log(level, message, *args)


async def wait_pair(coro1, coro2, label: str, logger: logging.Logger | None) -> None:
    t1 = asyncio.create_task(coro1)
    t2 = asyncio.create_task(coro2)
    done, pending = await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
    for task in pending:
        task.cancel()
    await asyncio.gather(*pending, return_exceptions=True)
    for task in done:
        try:
            exc = task.exception()
        except asyncio.CancelledError:
            exc = None
        if exc and logger:
            logger.debug("[%s] bridge task finished: %s", label, exc)


async def safe_close_writer(writer: asyncio.StreamWriter) -> None:
    try:
        writer.close()
        await writer.wait_closed()
    except Exception:
        pass
