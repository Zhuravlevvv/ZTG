from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .mtproto import (
    DEFAULT_CFPROXY_DOMAINS,
    FLOWSEAL_STYLE_DEFAULTS,
    dc_redirects_to_text,
    normalize_secret,
)

APP_NAME = "ZTG"
APP_DIR = Path.home() / ".ztg"
CONFIG_PATH = APP_DIR / "config.json"

DEFAULT_DC_REDIRECTS = dc_redirects_to_text(FLOWSEAL_STYLE_DEFAULTS)
DEFAULT_CFPROXY_DOMAINS_TEXT = "\n".join(DEFAULT_CFPROXY_DOMAINS)


@dataclass
class AppConfig:
    listen_host: str = "127.0.0.1"
    listen_port: int = 1443
    secret: str = ""
    dc_redirects: str = DEFAULT_DC_REDIRECTS
    cfproxy_domains: str = DEFAULT_CFPROXY_DOMAINS_TEXT
    auto_open_telegram: bool = True
    enable_cf_fallback: bool = True
    enable_tcp_fallback: bool = True
    log_level: str = "INFO"

    @classmethod
    def load(cls, path: Path = CONFIG_PATH) -> "AppConfig":
        if not path.exists():
            return cls(secret=normalize_secret(""))
        try:
            raw: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
            allowed = cls.__dataclass_fields__
            data = {k: v for k, v in raw.items() if k in allowed}
            cfg = cls(**data)
            cfg.secret = normalize_secret(cfg.secret)
            if not cfg.cfproxy_domains.strip():
                cfg.cfproxy_domains = DEFAULT_CFPROXY_DOMAINS_TEXT
            return cfg
        except Exception:
            return cls(secret=normalize_secret(""))

    def save(self, path: Path = CONFIG_PATH) -> None:
        self.secret = normalize_secret(self.secret)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
