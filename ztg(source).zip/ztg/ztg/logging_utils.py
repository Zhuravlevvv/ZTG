from __future__ import annotations

import logging
from typing import Callable


class CallbackHandler(logging.Handler):
    def __init__(self, callback: Callable[[str], None]):
        super().__init__()
        self.callback = callback

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.callback(self.format(record))
        except Exception:
            pass


def setup_logging(level: str = "INFO", callback: Callable[[str], None] | None = None) -> logging.Logger:
    logger = logging.getLogger("ztg")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s  %(levelname)-5s  %(message)s", datefmt="%H:%M:%S")
    if callback is not None:
        handler = CallbackHandler(callback)
    else:
        handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    return logger
