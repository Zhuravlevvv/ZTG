from __future__ import annotations

from .mtproto import build_mtproto_link, normalize_secret, proxy_link_host


def telegram_host_for_link(listen_host: str) -> str:
    return proxy_link_host(listen_host)


def build_telegram_mtproto_url(listen_host: str, listen_port: int, secret: str) -> str:
    return build_mtproto_link(listen_host, listen_port, normalize_secret(secret))
