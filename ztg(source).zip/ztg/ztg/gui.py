from __future__ import annotations

import asyncio
import sys
from pathlib import Path

from PySide6.QtCore import QThread, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QAction, QColor, QDesktopServices, QIcon
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFrame,
    QFormLayout,
    QGraphicsDropShadowEffect,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QPlainTextEdit,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSystemTrayIcon,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .config import APP_NAME, AppConfig, CONFIG_PATH
from .logging_utils import setup_logging
from .mtproto import MTProtoLocalService, normalize_secret, parse_cfproxy_domains, parse_dc_redirects
from .telegram import build_telegram_mtproto_url

ROOT_DIR = Path(__file__).resolve().parents[1]
ICON_PATH = ROOT_DIR / "resources" / "icons" / "ztg.ico"


class ProxyWorker(QThread):
    log_line = Signal(str)
    status = Signal(str)

    def __init__(self, config: AppConfig):
        super().__init__()
        self.config = config
        self.loop: asyncio.AbstractEventLoop | None = None
        self.stop_event: asyncio.Event | None = None
        self.service: MTProtoLocalService | None = None

    def run(self) -> None:
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.stop_event = asyncio.Event()
        self.loop.run_until_complete(self._main())
        self.loop.close()
        self.loop = None

    async def _main(self) -> None:
        logger = setup_logging(self.config.log_level, self.log_line.emit)
        self.service = MTProtoLocalService(
            listen_host=self.config.listen_host,
            listen_port=self.config.listen_port,
            secret_hex=self.config.secret,
            dc_redirects_text=self.config.dc_redirects,
            enable_cf_fallback=self.config.enable_cf_fallback,
            cfproxy_domains_text=self.config.cfproxy_domains,
            enable_tcp_fallback=self.config.enable_tcp_fallback,
            logger=logger,
        )
        try:
            await self.service.start()
            self.status.emit("running")
            assert self.stop_event is not None
            await self.stop_event.wait()
        except Exception as exc:
            self.log_line.emit(f"ОШИБКА: {exc}")
            self.status.emit("error")
        finally:
            try:
                if self.service is not None:
                    await self.service.stop()
            except Exception as exc:
                self.log_line.emit(f"ОШИБКА при остановке: {exc}")
            self.status.emit("stopped")

    def request_stop(self) -> None:
        if self.loop is not None and self.stop_event is not None:
            self.loop.call_soon_threadsafe(self.stop_event.set)


def apply_shadow(widget: QWidget, blur: int = 30, y: int = 12) -> None:
    shadow = QGraphicsDropShadowEffect(widget)
    shadow.setBlurRadius(blur)
    shadow.setOffset(0, y)
    shadow.setColor(QColor(0, 0, 0, 120))
    widget.setGraphicsEffect(shadow)


class SettingsDialog(QDialog):
    def __init__(self, config: AppConfig, log_text: str, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("Настройки")
        self.setMinimumSize(720, 620)
        self.resize(760, 660)
        self.config = config

        self.listen_host = QLineEdit(config.listen_host)
        self.listen_host.setFixedHeight(40)
        self.listen_port = QSpinBox()
        self.listen_port.setRange(1, 65535)
        self.listen_port.setValue(config.listen_port)
        self.listen_port.setFixedHeight(40)

        self.secret = QLineEdit(normalize_secret(config.secret))
        self.secret.setFixedHeight(40)
        self.regen_secret_btn = QPushButton("Новый")
        self.regen_secret_btn.setFixedSize(92, 40)

        secret_box = QWidget()
        secret_row = QHBoxLayout(secret_box)
        secret_row.setContentsMargins(0, 0, 0, 0)
        secret_row.setSpacing(8)
        secret_row.addWidget(self.secret, 1)
        secret_row.addWidget(self.regen_secret_btn)

        self.dc_redirects = QPlainTextEdit(config.dc_redirects)
        self.dc_redirects.setFixedHeight(86)
        self.dc_redirects.setPlaceholderText("2:149.154.167.220\n4:149.154.167.220")

        self.cf_domains = QPlainTextEdit(config.cfproxy_domains)
        self.cf_domains.setFixedHeight(104)
        self.cf_domains.setPlaceholderText("pclead.co.uk\noffshor.co.uk")

        self.auto_open_telegram = QCheckBox("Открывать Telegram автоматически")
        self.auto_open_telegram.setChecked(config.auto_open_telegram)
        self.enable_cf_fallback = QCheckBox("CF/WebSocket fallback")
        self.enable_cf_fallback.setChecked(config.enable_cf_fallback)
        self.enable_tcp_fallback = QCheckBox("TCP fallback")
        self.enable_tcp_fallback.setChecked(config.enable_tcp_fallback)

        self.log_level = QLineEdit(config.log_level)
        self.log_level.setFixedHeight(40)
        self.log_level.setPlaceholderText("INFO / DEBUG")

        self.logs = QPlainTextEdit(log_text)
        self.logs.setReadOnly(True)
        self.logs.setFixedHeight(110)

        content = QWidget()
        content.setMinimumWidth(640)
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(12)

        connection_card = self._card("Прокси")
        connection_grid = QGridLayout(connection_card)
        connection_grid.setContentsMargins(18, 16, 18, 16)
        connection_grid.setHorizontalSpacing(12)
        connection_grid.setVerticalSpacing(8)
        connection_grid.addWidget(self._card_title("Прокси"), 0, 0, 1, 4)
        connection_grid.addWidget(self._field_label("Адрес"), 1, 0)
        connection_grid.addWidget(self.listen_host, 2, 0, 1, 3)
        connection_grid.addWidget(self._field_label("Порт"), 1, 3)
        connection_grid.addWidget(self.listen_port, 2, 3)
        connection_grid.addWidget(self._field_label("Secret"), 3, 0, 1, 4)
        connection_grid.addWidget(secret_box, 4, 0, 1, 4)
        connection_grid.setColumnStretch(0, 1)
        connection_grid.setColumnStretch(1, 1)
        connection_grid.setColumnStretch(2, 1)
        connection_grid.setColumnStretch(3, 0)

        routing_card = self._card("Маршруты")
        routing_layout = QVBoxLayout(routing_card)
        routing_layout.setContentsMargins(18, 16, 18, 16)
        routing_layout.setSpacing(8)
        routing_layout.addWidget(self._card_title("Маршруты"))
        routing_layout.addWidget(self._field_label("DC → IP"))
        routing_layout.addWidget(self.dc_redirects)
        routing_layout.addWidget(self._field_label("CF fallback домены"))
        routing_layout.addWidget(self.cf_domains)

        options_card = self._card("Опции")
        options_grid = QGridLayout(options_card)
        options_grid.setContentsMargins(18, 16, 18, 16)
        options_grid.setHorizontalSpacing(12)
        options_grid.setVerticalSpacing(8)
        options_grid.addWidget(self._card_title("Опции"), 0, 0, 1, 2)
        options_grid.addWidget(self.auto_open_telegram, 1, 0)
        options_grid.addWidget(self.enable_cf_fallback, 1, 1)
        options_grid.addWidget(self.enable_tcp_fallback, 2, 0)
        options_grid.addWidget(self._field_label("Логи"), 2, 1)
        options_grid.addWidget(self.log_level, 3, 1)
        options_grid.setColumnStretch(0, 1)
        options_grid.setColumnStretch(1, 1)

        logs_card = self._card("Журнал")
        logs_layout = QVBoxLayout(logs_card)
        logs_layout.setContentsMargins(18, 16, 18, 16)
        logs_layout.setSpacing(8)
        logs_layout.addWidget(self._card_title("Журнал"))
        logs_layout.addWidget(self.logs)

        content_layout.addWidget(connection_card)
        content_layout.addWidget(routing_card)
        content_layout.addWidget(options_card)
        content_layout.addWidget(logs_card)
        content_layout.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(content)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("Сохранить")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self._try_accept)
        buttons.rejected.connect(self.reject)

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 22, 22, 18)
        root.setSpacing(14)
        title = QLabel("Настройки")
        title.setObjectName("DialogTitle")
        root.addWidget(title)
        root.addWidget(scroll, 1)
        root.addWidget(buttons)

        self.regen_secret_btn.clicked.connect(lambda: self.secret.setText(normalize_secret("")))
        self._apply_styles()

    def _field_label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("FieldLabel")
        return label

    def _card_title(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("CardTitle")
        return label

    def _card(self, title: str) -> QFrame:
        frame = QFrame()
        frame.setObjectName("SettingsCard")
        frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        return frame

    def _try_accept(self) -> None:
        if self.collect() is not None:
            self.accept()

    def collect(self) -> AppConfig | None:
        cfg = AppConfig(
            listen_host=self.listen_host.text().strip() or "127.0.0.1",
            listen_port=int(self.listen_port.value()),
            secret=normalize_secret(self.secret.text()),
            dc_redirects=self.dc_redirects.toPlainText().strip(),
            cfproxy_domains=self.cf_domains.toPlainText().strip(),
            auto_open_telegram=self.auto_open_telegram.isChecked(),
            enable_cf_fallback=self.enable_cf_fallback.isChecked(),
            enable_tcp_fallback=self.enable_tcp_fallback.isChecked(),
            log_level=(self.log_level.text().strip().upper() or "INFO"),
        )
        try:
            parse_dc_redirects(cfg.dc_redirects)
            parse_cfproxy_domains(cfg.cfproxy_domains)
            normalize_secret(cfg.secret)
        except Exception as exc:
            QMessageBox.warning(self, "Ошибка", str(exc))
            return None
        return cfg

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            QDialog { background: #0b1020; color: #edf2ff; font-family: Inter, Segoe UI, Arial; font-size: 14px; }
            QLabel#DialogTitle { color: #ffffff; font-size: 28px; font-weight: 900; }
            QLabel#CardTitle { color: #ffffff; font-size: 17px; font-weight: 900; }
            QLabel#FieldLabel { color: #9fb0d2; font-size: 12px; font-weight: 800; }
            QFrame#SettingsCard { background: #121a31; border: 1px solid #273653; border-radius: 18px; }
            QScrollArea { border: 0; background: transparent; }
            QScrollArea > QWidget > QWidget { background: transparent; }
            QLineEdit, QSpinBox, QPlainTextEdit { background: #0d1427; border: 1px solid #2b3a5c; border-radius: 12px; padding: 8px 10px; color: #f8fbff; selection-background-color: #3763ff; }
            QLineEdit:focus, QSpinBox:focus, QPlainTextEdit:focus { border: 1px solid #6f8cff; }
            QCheckBox { color: #edf2ff; spacing: 8px; min-height: 28px; }
            QPushButton { background: #1e2a45; border: 1px solid #31415f; border-radius: 12px; color: #edf2ff; padding: 8px 12px; font-weight: 800; }
            QPushButton:hover { background: #28385b; }
            QDialogButtonBox QPushButton { min-width: 112px; }
            """
        )


class InstructionDialog(QDialog):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("Инструкция")
        self.setMinimumSize(560, 420)

        title = QLabel("Инструкция")
        title.setObjectName("DialogTitle")
        text = QLabel(
            "1. Нажмите «Подключить».\n"
            "2. Нажмите «Открыть в Telegram».\n"
            "3. Если Telegram попросит подтверждение — нажмите «Подключить прокси».\n\n"
            "Если Telegram показывает подключение, но чаты не загружаются, откройте «Настройки» "
            "и проверьте, что включён CF/WebSocket fallback."
        )
        text.setWordWrap(True)
        text.setObjectName("InstructionText")

        btn = QPushButton("Понятно")
        btn.clicked.connect(self.accept)

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 28, 28, 28)
        root.setSpacing(18)
        root.addWidget(title)
        root.addWidget(text, 1)
        root.addWidget(btn, 0, Qt.AlignRight)
        self._apply_styles()

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            QDialog { background: #0b1020; color: #edf2ff; font-family: Inter, Segoe UI, Arial; font-size: 15px; }
            QLabel#DialogTitle { color: #ffffff; font-size: 28px; font-weight: 800; }
            QLabel#InstructionText { color: #dbe5ff; line-height: 150%; }
            QPushButton { background: #6f8cff; border: 0; border-radius: 14px; color: white; padding: 12px 18px; font-weight: 800; min-width: 110px; }
            QPushButton:hover { background: #829cff; }
            """
        )


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(760, 560)
        self.setMinimumSize(680, 500)

        self.config = AppConfig.load()
        self.worker: ProxyWorker | None = None
        self.pending_open_telegram = False
        self.telegram_opened_for_session = False
        self.log_lines: list[str] = []

        self.app_icon = QIcon(str(ICON_PATH)) if ICON_PATH.exists() else QIcon()
        self.setWindowIcon(self.app_icon)

        self.status_dot = QLabel("●")
        self.status_dot.setObjectName("StatusDot")
        self.status_label = QLabel("Отключено")
        self.status_label.setObjectName("StatusLabel")

        self.start_btn = QPushButton("Подключить")
        self.start_btn.setObjectName("PrimaryButton")
        self.open_tg_btn = QPushButton("Открыть в Telegram")
        self.stop_btn = QPushButton("Отключить")
        self.settings_btn = QPushButton("Настройки")
        self.instruction_btn = QPushButton("Инструкция")

        for btn in (self.start_btn, self.open_tg_btn, self.stop_btn, self.settings_btn, self.instruction_btn):
            btn.setMinimumHeight(52)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        self._build_layout()
        self._wire_events()
        self._setup_tray()
        self._apply_styles()
        self.set_status("stopped")

    def _build_layout(self) -> None:
        root = QWidget()
        root.setObjectName("Root")
        outer = QVBoxLayout(root)
        outer.setContentsMargins(34, 30, 34, 22)
        outer.setSpacing(18)

        card = QFrame()
        card.setObjectName("MainCard")
        apply_shadow(card)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(34, 34, 34, 30)
        card_layout.setSpacing(22)

        logo = QLabel("ZTG")
        logo.setObjectName("Logo")
        subtitle = QLabel("MTProto-прокси")
        subtitle.setObjectName("Subtitle")
        subtitle.setAlignment(Qt.AlignCenter)

        status_box = QFrame()
        status_box.setObjectName("StatusBox")
        status_layout = QHBoxLayout(status_box)
        status_layout.setContentsMargins(18, 14, 18, 14)
        status_layout.setSpacing(10)
        status_layout.addStretch(1)
        status_layout.addWidget(self.status_dot)
        status_layout.addWidget(self.status_label)
        status_layout.addStretch(1)

        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(12)
        grid.addWidget(self.start_btn, 0, 0)
        grid.addWidget(self.open_tg_btn, 0, 1)
        grid.addWidget(self.stop_btn, 1, 0)
        grid.addWidget(self.settings_btn, 1, 1)
        grid.addWidget(self.instruction_btn, 2, 0, 1, 2)

        card_layout.addStretch(1)
        card_layout.addWidget(logo, 0, Qt.AlignCenter)
        card_layout.addWidget(subtitle)
        card_layout.addWidget(status_box)
        card_layout.addLayout(grid)
        card_layout.addStretch(1)

        footer = QLabel("Developed by Zhuravlev.")
        footer.setObjectName("Footer")
        footer.setAlignment(Qt.AlignCenter)

        outer.addWidget(card, 1)
        outer.addWidget(footer)
        self.setCentralWidget(root)

    def _wire_events(self) -> None:
        self.start_btn.clicked.connect(self.start_proxy)
        self.stop_btn.clicked.connect(self.stop_proxy)
        self.open_tg_btn.clicked.connect(self.open_telegram_clicked)
        self.settings_btn.clicked.connect(self.open_settings)
        self.instruction_btn.clicked.connect(self.open_instruction)

    def _setup_tray(self) -> None:
        self.tray = QSystemTrayIcon(self.app_icon, self)
        self.tray.setToolTip(APP_NAME)
        menu = QMenu()
        open_action = QAction("Показать ZTG", self)
        tg_action = QAction("Открыть в Telegram", self)
        settings_action = QAction("Настройки", self)
        quit_action = QAction("Выход", self)
        open_action.triggered.connect(self.show_normal)
        tg_action.triggered.connect(self.open_telegram_clicked)
        settings_action.triggered.connect(self.open_settings)
        quit_action.triggered.connect(self.close)
        menu.addAction(open_action)
        menu.addAction(tg_action)
        menu.addAction(settings_action)
        menu.addSeparator()
        menu.addAction(quit_action)
        self.tray.setContextMenu(menu)
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()

    def show_normal(self) -> None:
        self.show()
        self.raise_()
        self.activateWindow()

    def start_proxy(self) -> None:
        if self.worker and self.worker.isRunning():
            return
        self.config.save()
        self.log_lines.clear()
        self.telegram_opened_for_session = False
        self.worker = ProxyWorker(self.config)
        self.worker.log_line.connect(self.append_log)
        self.worker.status.connect(self.set_status)
        self.worker.finished.connect(lambda: self.set_status("stopped"))
        self.worker.start()
        self.set_status("starting")

    def stop_proxy(self) -> None:
        self.pending_open_telegram = False
        if self.worker and self.worker.isRunning():
            self.worker.request_stop()
            self.set_status("stopping")
        else:
            self.set_status("stopped")

    def open_telegram_clicked(self) -> None:
        self.pending_open_telegram = True
        if not (self.worker and self.worker.isRunning()):
            self.start_proxy()
        elif self.current_state() == "running":
            self.open_telegram_now()

    def open_telegram_now(self) -> None:
        url = build_telegram_mtproto_url(self.config.listen_host, self.config.listen_port, self.config.secret)
        QDesktopServices.openUrl(QUrl(url))
        self.telegram_opened_for_session = True
        self.pending_open_telegram = False

    def open_settings(self) -> None:
        was_running = bool(self.worker and self.worker.isRunning())
        dlg = SettingsDialog(self.config, "\n".join(self.log_lines[-250:]), self)
        if dlg.exec() != QDialog.Accepted:
            return
        cfg = dlg.collect()
        if cfg is None:
            return
        self.config = cfg
        self.config.save()
        if was_running:
            self.pending_open_telegram = False
            self.stop_proxy()
            QTimer.singleShot(450, self.start_proxy)

    def open_instruction(self) -> None:
        InstructionDialog(self).exec()

    def append_log(self, line: str) -> None:
        self.log_lines.append(line)
        if len(self.log_lines) > 1000:
            self.log_lines = self.log_lines[-700:]

    def current_state(self) -> str:
        return getattr(self, "_state", "stopped")

    def set_status(self, state: str) -> None:
        self._state = state
        if state == "running":
            self.status_label.setText("Подключено")
            self.status_dot.setProperty("state", "running")
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            if (self.pending_open_telegram or self.config.auto_open_telegram) and not self.telegram_opened_for_session:
                QTimer.singleShot(650, self.open_telegram_now)
        elif state == "starting":
            self.status_label.setText("Подключение…")
            self.status_dot.setProperty("state", "starting")
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
        elif state == "stopping":
            self.status_label.setText("Отключение…")
            self.status_dot.setProperty("state", "starting")
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)
        elif state == "error":
            self.status_label.setText("Ошибка")
            self.status_dot.setProperty("state", "error")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
        else:
            self.status_label.setText("Отключено")
            self.status_dot.setProperty("state", "stopped")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            self.telegram_opened_for_session = False
        self.status_dot.style().unpolish(self.status_dot)
        self.status_dot.style().polish(self.status_dot)

    def closeEvent(self, event) -> None:  # noqa: N802
        if self.worker and self.worker.isRunning():
            self.worker.request_stop()
            self.worker.wait(2500)
        event.accept()

    def _apply_styles(self) -> None:
        self.setStyleSheet(
            """
            QWidget#Root { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0a1020, stop:1 #111936); }
            QFrame#MainCard { background: rgba(18, 26, 49, 0.96); border: 1px solid #273653; border-radius: 32px; }
            QLabel#Logo { color: #ffffff; font-size: 76px; font-weight: 900; letter-spacing: 3px; }
            QLabel#Subtitle { color: #b8c3df; font-size: 18px; font-weight: 600; }
            QLabel#Footer { color: #7785a7; font-size: 13px; }
            QFrame#StatusBox { background: #0f172b; border: 1px solid #243250; border-radius: 18px; }
            QLabel#StatusLabel { color: #f7faff; font-size: 18px; font-weight: 800; }
            QLabel#StatusDot { font-size: 26px; color: #7785a7; }
            QLabel#StatusDot[state="running"] { color: #50e3a4; }
            QLabel#StatusDot[state="starting"] { color: #ffd166; }
            QLabel#StatusDot[state="error"] { color: #ff6b6b; }
            QPushButton { background: #1e2a45; border: 1px solid #31415f; border-radius: 16px; color: #edf2ff; font-size: 15px; font-weight: 800; padding: 0 18px; }
            QPushButton:hover { background: #28385b; }
            QPushButton:disabled { color: #6e7893; background: #141c31; border-color: #202b44; }
            QPushButton#PrimaryButton { background: #6f8cff; border: 1px solid #8aa1ff; color: white; }
            QPushButton#PrimaryButton:hover { background: #829cff; }
            QMenu { background: #121a31; color: #edf2ff; border: 1px solid #273653; padding: 6px; }
            QMenu::item { padding: 8px 22px; border-radius: 8px; }
            QMenu::item:selected { background: #28385b; }
            """
        )


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    if ICON_PATH.exists():
        app.setWindowIcon(QIcon(str(ICON_PATH)))
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
