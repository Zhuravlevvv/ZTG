from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import socket
import ssl
import struct
from dataclasses import dataclass
from typing import Optional, Tuple

try:
    import certifi
except Exception:  # pragma: no cover - certifi is packaged in requirements
    certifi = None


_WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

_ST_BB = struct.Struct(">BB")
_ST_BBH = struct.Struct(">BBH")
_ST_BBQ = struct.Struct(">BBQ")
_ST_BB4S = struct.Struct(">BB4s")
_ST_BBH4S = struct.Struct(">BBH4s")
_ST_BBQ4S = struct.Struct(">BBQ4s")
_ST_H = struct.Struct(">H")
_ST_Q = struct.Struct(">Q")


def _verified_ssl_context() -> ssl.SSLContext:
    """Return a TLS context that works inside PyInstaller builds.

    On Windows/macOS packaged applications OpenSSL sometimes does not see the
    system certificate store. Flowseal relies on a normal verified TLS context;
    here we explicitly add certifi's CA bundle so CF/WebSocket fallback domains
    do not fail with CERTIFICATE_VERIFY_FAILED in the frozen app.
    """
    ctx = ssl.create_default_context()
    if certifi is not None:
        try:
            ctx.load_verify_locations(cafile=certifi.where())
        except Exception:
            pass
    try:
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    except Exception:
        pass
    return ctx


def _relaxed_ssl_context() -> ssl.SSLContext:
    """Last-resort TLS context.

    Telegram MTProto payload stays encrypted by Telegram's own transport crypto,
    but TLS certificate verification is still preferred. This context is used
    only after the verified context fails with SSLCertVerificationError, which is
    common in improperly bundled desktop builds without CA roots.
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    except Exception:
        pass
    return ctx


_SSL_CTX = _verified_ssl_context()
_RELAXED_SSL_CTX: ssl.SSLContext | None = None


def xor_mask(data: bytes, mask: bytes) -> bytes:
    if not data:
        return data
    repeated = (mask * (len(data) // 4 + 1))[: len(data)]
    return bytes(a ^ b for a, b in zip(data, repeated))


def set_tcp_opts(writer: asyncio.StreamWriter, buffer_size: int = 256 * 1024) -> None:
    transport = writer.transport
    sock = transport.get_extra_info("socket")
    if sock is None:
        return
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except OSError:
        pass
    for opt in (socket.SO_SNDBUF, socket.SO_RCVBUF):
        try:
            sock.setsockopt(socket.SOL_SOCKET, opt, int(buffer_size))
        except OSError:
            pass


@dataclass
class WsHandshakeError(Exception):
    status_code: int
    status_line: str
    headers: dict[str, str]

    def __str__(self) -> str:
        return f"HTTP {self.status_code}: {self.status_line}"

    @property
    def is_redirect(self) -> bool:
        return self.status_code in {301, 302, 303, 307, 308}


class RawWebSocket:
    OP_CONTINUATION = 0x0
    OP_TEXT = 0x1
    OP_BINARY = 0x2
    OP_CLOSE = 0x8
    OP_PING = 0x9
    OP_PONG = 0xA

    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, *, relaxed_tls: bool = False):
        self.reader = reader
        self.writer = writer
        self.closed = False
        self.relaxed_tls = relaxed_tls

    @classmethod
    async def connect(
        cls,
        ip: str,
        domain: str,
        *,
        path: str = "/apiws",
        timeout: float = 10.0,
        buffer_size: int = 256 * 1024,
    ) -> "RawWebSocket":
        try:
            return await cls._connect_once(
                ip,
                domain,
                path=path,
                timeout=timeout,
                buffer_size=buffer_size,
                ssl_context=_SSL_CTX,
                relaxed_tls=False,
            )
        except ssl.SSLCertVerificationError:
            # This is the exact error in the user's log. Retry with a relaxed
            # context instead of endlessly rotating CF domains.
            global _RELAXED_SSL_CTX
            if _RELAXED_SSL_CTX is None:
                _RELAXED_SSL_CTX = _relaxed_ssl_context()
            return await cls._connect_once(
                ip,
                domain,
                path=path,
                timeout=timeout,
                buffer_size=buffer_size,
                ssl_context=_RELAXED_SSL_CTX,
                relaxed_tls=True,
            )

    @classmethod
    async def _connect_once(
        cls,
        ip: str,
        domain: str,
        *,
        path: str,
        timeout: float,
        buffer_size: int,
        ssl_context: ssl.SSLContext,
        relaxed_tls: bool,
    ) -> "RawWebSocket":
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, 443, ssl=ssl_context, server_hostname=domain),
            timeout=min(timeout, 10.0),
        )
        set_tcp_opts(writer, buffer_size)

        key = base64.b64encode(os.urandom(16)).decode("ascii")
        # Flowseal-style WebSocket handshake. Telegram's MTProto over WSS needs
        # Sec-WebSocket-Protocol: binary; browser-like Origin/User-Agent keep the
        # request close to the reference implementation.
        request = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {domain}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            "Sec-WebSocket-Protocol: binary\r\n"
            "Origin: https://web.telegram.org\r\n"
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36\r\n"
            "\r\n"
        )
        writer.write(request.encode("ascii"))
        await writer.drain()

        lines: list[str] = []
        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=timeout)
                if line in (b"\r\n", b"\n", b""):
                    break
                lines.append(line.decode("utf-8", errors="replace").strip())
        except Exception:
            await cls._close_writer(writer)
            raise

        if not lines:
            await cls._close_writer(writer)
            raise WsHandshakeError(0, "empty response", {})

        status_line = lines[0]
        status_parts = status_line.split(" ", 2)
        try:
            status_code = int(status_parts[1])
        except Exception:
            status_code = 0

        headers: dict[str, str] = {}
        for line in lines[1:]:
            if ":" in line:
                name, value = line.split(":", 1)
                headers[name.lower().strip()] = value.strip()

        if status_code != 101:
            await cls._close_writer(writer)
            raise WsHandshakeError(status_code, status_line, headers)

        accept = headers.get("sec-websocket-accept")
        expected = base64.b64encode(hashlib.sha1((key + _WS_GUID).encode("ascii")).digest()).decode("ascii")
        if accept and accept != expected:
            await cls._close_writer(writer)
            raise WsHandshakeError(status_code, "invalid websocket accept header", headers)

        return cls(reader, writer, relaxed_tls=relaxed_tls)

    async def send(self, data: bytes) -> None:
        if self.closed:
            raise ConnectionError("WebSocket is closed")
        self.writer.write(self._build_frame(self.OP_BINARY, data, mask=True))
        await self.writer.drain()

    async def send_batch(self, parts: list[bytes]) -> None:
        if self.closed:
            raise ConnectionError("WebSocket is closed")
        for part in parts:
            if part:
                self.writer.write(self._build_frame(self.OP_BINARY, part, mask=True))
        await self.writer.drain()

    async def recv(self) -> Optional[bytes]:
        chunks: list[bytes] = []
        while not self.closed:
            opcode, payload, fin = await self._read_frame()
            if opcode == self.OP_CLOSE:
                self.closed = True
                try:
                    self.writer.write(self._build_frame(self.OP_CLOSE, payload[:2], mask=True))
                    await self.writer.drain()
                except Exception:
                    pass
                return None
            if opcode == self.OP_PING:
                self.writer.write(self._build_frame(self.OP_PONG, payload, mask=True))
                await self.writer.drain()
                continue
            if opcode == self.OP_PONG:
                continue
            if opcode in (self.OP_BINARY, self.OP_TEXT, self.OP_CONTINUATION):
                chunks.append(payload)
                if fin:
                    return b"".join(chunks)
        return None

    async def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        try:
            self.writer.write(self._build_frame(self.OP_CLOSE, b"", mask=True))
            await self.writer.drain()
        except Exception:
            pass
        await self._close_writer(self.writer)

    @staticmethod
    async def _close_writer(writer: asyncio.StreamWriter) -> None:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass

    @staticmethod
    def _build_frame(opcode: int, data: bytes, *, mask: bool) -> bytes:
        first = 0x80 | opcode
        length = len(data)
        if not mask:
            if length < 126:
                return _ST_BB.pack(first, length) + data
            if length < 65536:
                return _ST_BBH.pack(first, 126, length) + data
            return _ST_BBQ.pack(first, 127, length) + data

        mask_key = os.urandom(4)
        masked = xor_mask(data, mask_key)
        if length < 126:
            return _ST_BB4S.pack(first, 0x80 | length, mask_key) + masked
        if length < 65536:
            return _ST_BBH4S.pack(first, 0x80 | 126, length, mask_key) + masked
        return _ST_BBQ4S.pack(first, 0x80 | 127, length, mask_key) + masked

    async def _read_frame(self) -> Tuple[int, bytes, bool]:
        header = await self.reader.readexactly(2)
        fin = bool(header[0] & 0x80)
        opcode = header[0] & 0x0F
        length = header[1] & 0x7F
        if length == 126:
            length = _ST_H.unpack(await self.reader.readexactly(2))[0]
        elif length == 127:
            length = _ST_Q.unpack(await self.reader.readexactly(8))[0]

        if header[1] & 0x80:
            mask = await self.reader.readexactly(4)
            payload = await self.reader.readexactly(length)
            payload = xor_mask(payload, mask)
        else:
            payload = await self.reader.readexactly(length)
        return opcode, payload, fin
