from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ICON = ROOT / "resources" / "icons" / "ztg.ico"


def main() -> None:
    cmd = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--windowed",
        "--name",
        "ZTG",
        "--add-data",
        f"{ROOT / 'resources'}{os.pathsep}resources",
        "--collect-data",
        "certifi",
    ]
    if ICON.exists():
        cmd.extend(["--icon", str(ICON)])
    cmd.append(str(ROOT / "run_desktop.py"))
    subprocess.check_call(cmd, cwd=ROOT)


if __name__ == "__main__":
    main()
