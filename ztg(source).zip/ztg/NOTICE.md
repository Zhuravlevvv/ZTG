# Notices

ZTG includes a Python implementation of a Telegram MTProto-to-WebSocket bridge compatible with the public behavior described by Flowseal/tg-ws-proxy.

Reference project:
- Flowseal/tg-ws-proxy
- License: MIT
- Repository: https://github.com/Flowseal/tg-ws-proxy

ZTG branding, desktop UI and packaging are separate and use the ZTG name/logo.
