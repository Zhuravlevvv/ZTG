# ZTG

ZTG — десктопное приложение для запуска локального MTProto-прокси Telegram Desktop.

```text
Telegram Desktop → 127.0.0.1:1443 → MTProto bridge → WebSocket /apiws → Telegram DC
                                                    ↘ CF fallback → TCP fallback
```
\
## Что исправлено в этой версии

- Исправлена причина, из-за которой Telegram показывал «подключено», но в настройках не было пинга: CF fallback падал на проверке TLS-сертификатов (`CERTIFICATE_VERIFY_FAILED`).
- В WebSocket-клиент добавлен `certifi` CA-bundle для Windows/PyInstaller-сборок.
- Добавлен аварийный TLS CA fallback: если окружение всё равно не видит корневой сертификат, ZTG пробует повторное подключение и пишет это в журнал.

## Запуск из исходников

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run_desktop.py
```

## Сборка приложения

```bash
pip install -r requirements.txt
python scripts/build_desktop.py
```

Готовый бинарник появится в папке `dist/`.

## Подключение Telegram

1. Запустите ZTG.
2. Нажмите **Открыть в Telegram**.
3. ZTG запустит локальный MTProto-прокси и откроет Telegram с готовой ссылкой.
4. Если Telegram покажет окно подтверждения — нажмите **Подключить прокси**.

## Настройки

В окне **Настройки** можно изменить:

- локальный адрес и порт;
- MTProto secret;
- DC → IP;
- CF fallback домены;
- автозапуск Telegram;
- уровень логов.


